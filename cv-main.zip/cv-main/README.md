# cv
Host your cv on S3 bucket


Hi  Guys,

This folder has my CV and the style file attached with it. 

Thank  you 
