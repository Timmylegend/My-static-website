# cv
Host your cv on S3 bucket


Hi  Guys,

This folder has my CV and the style file attached with it. I have also a blog on the following link how to set up. If you have any question please just get in touch either via email or via the contact page through my website. http://petrucsik.co.uk

Thank  you 
